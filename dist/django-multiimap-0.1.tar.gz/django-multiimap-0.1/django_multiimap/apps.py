from django.apps import AppConfig


class DjangoMultiimapConfig(AppConfig):
    name = 'django_multiimap'
